function lessonTypeLabel(type) {
  return type === "full" ? "FULL COURSE" : "INTRO";
}

function lessonTypeClass(type) {
  return type === "full" ? "full" : "intro";
}

async function passLesson(lessonId) {
  const user = getStoredUser();
  if (!user?.id) {
    return showToast("Not logged in", "Please sign in again.", "warn");
  }

  const result = await apiRequest(`/lessons/${lessonId}/pass/${user.id}`, "POST", null, { allowRefresh: true });
  if (result?.error) {
    return showToast("Can't mark lesson", result.error, "warn");
  }

  showToast("Completed", "Lesson marked as passed.", "success");
  await loadLessons();
  await loadProfileSummary();
}

function renderLessonCard(lesson) {
  const passed = !!lesson.passed;
  return `
    <article class="lesson-card glass reveal">
      <div class="lesson-top">
        <span class="badge ${lessonTypeClass(lesson.lessonType)}">${lessonTypeLabel(lesson.lessonType)}</span>
        ${passed ? '<span class="badge completed">COMPLETED</span>' : ''}
      </div>

      <h4 class="lesson-title">${lesson.title}</h4>
      <p>${lesson.description}</p>

      <div class="lesson-actions">
        <a class="btn btn-secondary btn-sm" href="${lesson.videoLink}" target="_blank" rel="noopener">
          Watch on YouTube
        </a>
        ${
          passed
            ? '<span class="lesson-progress">Already completed</span>'
            : `<button class="btn btn-primary btn-sm" onclick="passLesson(${lesson.id})">Mark as Completed</button>`
        }
      </div>
    </article>
  `;
}

async function loadLessons() {
  const response = await apiRequest("/lessons");

  console.log(response);

  if (response?.error) {
    showToast("Error", response.error, "warn");
    return;
  }

  const lessons = Array.isArray(response)
    ? response
    : response.data || [];

  const introEl = document.getElementById("introLessons");
  const fullEl = document.getElementById("fullLessons");

  if (!introEl || !fullEl) return;

  const introLessons = lessons.filter(
    item => item.lessonType === "intro"
  );

  const fullLessons = lessons.filter(
    item => item.lessonType === "full"
  );

  introEl.innerHTML = introLessons.length
    ? introLessons.map(renderLessonCard).join("")
    : '<div class="notice">No intro lessons yet.</div>';

  fullEl.innerHTML = fullLessons.length
    ? fullLessons.map(renderLessonCard).join("")
    : '<div class="notice">No full courses yet.</div>';
}

async function loadLessonsAdmin() {
  const data = await apiRequest("/lessons");
  if (data?.error) return [];

  const list = document.getElementById("adminLessonsList");
  if (!list) return data || [];

  list.innerHTML = (data || []).map(item => `
    <div class="panel-item">
      <div>
        <strong>${item.title}</strong>
        <small>${item.lessonType.toUpperCase()} · ${item.description}</small>
      </div>
      <button class="btn btn-danger btn-sm" onclick="deleteLesson(${item.id})">Delete</button>
    </div>
  `).join("") || '<div class="notice">No lessons yet.</div>';

  return data || [];
}

async function createLesson() {
  const title = document.getElementById("lessonTitle").value.trim();
  const description = document.getElementById("lessonDescription").value.trim();
  const lessonType = document.getElementById("lessonType").value;
  const videoLink = document.getElementById("lessonVideo").value.trim();

  if (!title || !description || !videoLink) {
    return showToast("Missing data", "Fill all lesson fields.", "warn");
  }

  const result = await apiRequest("/lessons", "POST", { title, description, lessonType, videoLink });
  if (result?.error) return showToast("Error", result.error, "warn");

  showToast("Lesson created", "New lesson added.", "success");
  document.getElementById("lessonTitle").value = "";
  document.getElementById("lessonDescription").value = "";
  document.getElementById("lessonVideo").value = "";

  await loadLessonsAdmin();
}

async function deleteLesson(id) {
  if (!confirm("Delete this lesson?")) return;
  const result = await apiRequest(`/lessons/${id}`, "DELETE");
  if (result?.error) return showToast("Error", result.error, "warn");
  showToast("Lesson deleted", "Removed successfully.", "success");
  await loadLessonsAdmin();
  if (document.getElementById("introLessons")) {
    await loadLessons();
  }
}
