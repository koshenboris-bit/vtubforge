async function loadProfileSummary() {
  const user = getStoredUser();
  const me = await apiRequest("/users/me");
  if (me?.error) {
    showToast("Profile error", me.error, "warn");
    return;
  }

  const profileName = document.getElementById("profileName");
  const profileRole = document.getElementById("profileRole");
  const lastLesson = document.getElementById("lastLesson");
  const completedCount = document.getElementById("completedCount");
  const completedList = document.getElementById("completedList");

  if (!profileName || !profileRole || !lastLesson || !completedCount || !completedList) return;

  profileName.textContent = me.login;
  profileRole.textContent = me.role;
  lastLesson.textContent = me.lastLesson ? me.lastLesson.title : "No completed lessons yet";

  const lessons = await apiRequest("/lessons");
  const completed = (lessons || []).filter(item => item.passed);

  completedCount.textContent = String(completed.length);
  completedList.innerHTML = completed.length
    ? completed.map(item => `<span class="chip">${item.title}</span>`).join("")
    : '<div class="notice">You have not completed any lessons yet.</div>';
}
