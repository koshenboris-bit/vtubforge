async function loadNews() {
  const data = await apiRequest("/news");
  const news = Array.isArray(data) ? data : [];

  const featured = document.getElementById("featuredNews");
  const list = document.getElementById("newsList");
  const adminList = document.getElementById("adminNewsList");

  if (featured) {
    const top = news[0];
    featured.innerHTML = top ? `
      <div class="news-hero-main">
        <span class="news-eyebrow">Featured update</span>
        <h2 class="news-hero-title">${top.title}</h2>
        <p class="news-hero-text">${top.content}</p>
      </div>
      <div class="news-hero-side">
        <div class="news-feature-list">
          <div class="news-feature">Fresh lesson releases and platform updates.</div>
          <div class="news-feature">Fast announcements for VTuber students and admins.</div>
          <div class="news-feature">Stylish cards, clear structure, no clutter.</div>
        </div>
      </div>
    ` : '<div class="notice">No news yet.</div>';
  }

  if (list) {
    const items = news.slice(1);
    list.innerHTML = items.length
      ? items.map((item, index) => `
        <article class="news-card glass reveal">
          <span class="news-date">Update ${index + 2}</span>
          <h3>${item.title}</h3>
          <p>${item.content}</p>
          <div class="news-footer">
            <span>VTuberForge bulletin</span>
            <span>Live</span>
          </div>
        </article>
      `).join("")
      : '<div class="notice">No more news items yet.</div>';
  }

  if (adminList) {
    adminList.innerHTML = news.length
      ? news.map(item => `
        <div class="panel-item">
          <div>
            <strong>${item.title}</strong>
            <small>${item.content}</small>
          </div>
          <button class="btn btn-danger btn-sm" onclick="deleteNews(${item.id})">Delete</button>
        </div>
      `).join("")
      : '<div class="notice">No news yet.</div>';
  }
}

async function createNews() {
  const title = document.getElementById("newsTitle").value.trim();
  const content = document.getElementById("newsContent").value.trim();

  if (!title || !content) {
    return showToast("Missing data", "Enter title and content.", "warn");
  }

  const result = await apiRequest("/news", "POST", { title, content });
  if (result?.error) return showToast("Error", result.error, "warn");

  showToast("News created", "Announcement added.", "success");
  document.getElementById("newsTitle").value = "";
  document.getElementById("newsContent").value = "";
  await loadNews();
}

async function deleteNews(id) {
  if (!confirm("Delete this news item?")) return;
  const result = await apiRequest(`/news/${id}`, "DELETE");
  if (result?.error) return showToast("Error", result.error, "warn");
  showToast("News deleted", "Removed successfully.", "success");
  await loadNews();
}
