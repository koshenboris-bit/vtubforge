async function loginUser() {
  const login = document.getElementById("loginInput").value.trim();
  const password = document.getElementById("passwordInput").value.trim();

  if (!login || !password) {
    return showToast("Missing data", "Please enter login and password.", "warn");
  }

  const data = await apiRequest("/login", "POST", { login, password }, { allowRefresh: false });

  if (data?.error) {
    return showToast("Login failed", data.error, "warn");
  }

  localStorage.setItem("accessToken", data.accessToken);
  localStorage.setItem("refreshToken", data.refreshToken);
  localStorage.setItem("user", JSON.stringify(data.user));

  showToast("Welcome back", "Login successful.", "success");
  setTimeout(() => window.location.href = "lessons.html", 350);
}

async function registerUser() {
  const login = document.getElementById("loginInput").value.trim();
  const password = document.getElementById("passwordInput").value.trim();

  if (!login || !password) {
    return showToast("Missing data", "Please enter login and password.", "warn");
  }

  const data = await apiRequest("/register", "POST", { login, password }, { allowRefresh: false });

  if (data?.error) {
    return showToast("Registration failed", data.error, "warn");
  }

  localStorage.setItem("accessToken", data.accessToken);
  localStorage.setItem("refreshToken", data.refreshToken);
  localStorage.setItem("user", JSON.stringify(data.user));

  showToast("Account created", "Registration successful.", "success");
  setTimeout(() => window.location.href = "lessons.html", 350);
}
